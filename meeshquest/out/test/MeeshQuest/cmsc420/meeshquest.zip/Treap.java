package cmsc420.sortedmap;

import java.util.*;
import java.lang.UnsupportedOperationException;

/**
 * Treap structure (Map/SortedMap interfaces)
 *
 * Map Interface
 * Implements: clear, containsKey, containsValue, equals, get, hashCode, isEmpty, put, putAll, size
 * Doesn't implement: remove, keySet, values
 *
 * Sorted Map Interface
 * Implements: comparator, subMap, firstKey, lastKey, entrySet
 * Doesn't implement: headMap, tailMap
 *
 */
public class Treap<K,V> extends AbstractMap<K,V> implements SortedMap<K,V> {

    private TreapNode<K,V> root;            // treap root node
    private int size;                       // number of nodes in the treap
    private int modCount;                   // number of operations performed
    private Comparator<K> comparator;       // generic comparator

    // CONSTRUCTORS

    public Treap() {
        this.root = null;
        this.size = 0;
        this.modCount = 0;
        comparator = null;
    }

    public Treap(Comparator<K> comparator) {
        this.root = null;
        this.size = 0;
        this.modCount = 0;
        this.comparator = comparator;
    }

    // GETTER METHODS

    /**
     * Returns the root node of the Treap
     * @return
     */
    public TreapNode<K, V> getRoot() {
        return root;
    }

    /**
     * Returns the number of operations already made on the Treap
     * @return
     */
    public int getModCount() {
        return modCount;
    }

    // IMPLEMENTED METHODS (Map Interface)

    /**
     * Clears all nodes from the Treap
     */
    public void clear() {
        modCount++;
        size = 0;
        root = null;
    }

    /**
     * Checks if the Treap contains a node with the given key
     *
     * @param key
     * @return
     */
    public boolean containsKey(Object key) {
        return this.get(key) != null;
    }

    /**
     * Checks if the Treap contains a node with the given value
     * @param value
     * @return
     */
    public boolean containsValue(Object value) {

        // code taken from treemap.java
        for (TreapNode<K,V> node = getFirstEntry(); node != null; node = successor(node)) {
            if (value.equals(node.value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets value from the Treap node with the given key
     * Returns null if the key doesn't exist
     * @param key
     * @return
     */
    @Override
    public V get(Object key) {

        if (key == null) {
            throw new NullPointerException();
        }
        if (comparator != null) {
            return getUsingComparator(key);
        }
        TreapNode<K,V> node = root;
        Comparable<? super K> k = (Comparable<? super K>) key;

        while (node != null) {
            int result = k.compareTo(node.key);
            if (result < 0) {
                node = node.left;
            } else if (result > 0) {
                node = node.right;
            } else return node.value;
        }
        return null;
    }

    public V getUsingComparator(Object key) {

        TreapNode<K,V> node = root;
        K k = (K) key;
        while (node != null) {
            int result = comparator.compare(k, node.key);
            if (result < 0) {
                node = node.left;
            } else if (result > 0) {
                node = node.right;
            } else return node.value;
        }
        return null;

    }

    /**
     * Checks whether the Treap is empty or not
     * @return
     */
    @Override
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Inserts a node with a key and value into the Treap
     * @param key
     * @param value
     * @return
     */
    @Override
    public V put(K key, V value) {

        // if the Treap already contains key, updated value
        if (containsKey(key)) {
            return getEntry(key).setValue(value);
        }
        else {
            // my Treap does not accept null node values
            if (key == null || value == null) {
                throw new NullPointerException();
            }
            if (comparator == null) {
                root = insert(root, null, key, value);
            }
            else {
                root = insertUsingComparator(root, null, key, value);
            }
            size++;
        }
        modCount++;
        return null;
    }

    /**
     * Recursive implementation of insertion in Treap
     * Taken from geeksforgeeks.com
     */
    public TreapNode<K,V> insert(TreapNode<K, V> root, TreapNode<K,V> parent, K key, V value)
    {
        // If root is NULL, create a new node and return it
        if (root == null){
            //changed null -> parent
            return new TreapNode(key, value, parent);
        }

        Comparable<? super K> k = (Comparable<? super K>) key;
        int greaterThanRoot = k.compareTo(root.key);

        // If key is smaller than root
        if (greaterThanRoot < 0)
        {
            // Insert in left subtree
            root.left = insert(root.left, root, key, value);

            // Fix Max Heap property if it is violated
            if (root.left.priority > root.priority) {
                root = rightRotate(root);
            }
        }
        else  // If key is greater / equal to the root
        {
            // Insert in right subtree
            root.right = insert(root.right, root, key, value);

            // Fix Max Heap property if it is violated
            if (root.right.priority > root.priority) {
                root = leftRotate(root);
            }
        }
        return root;
    }

    /**
     * Recursive implementation of insertion in Treap
     * Taken from geeksforgeeks.com
     */
    public TreapNode<K,V> insertUsingComparator(TreapNode<K,V> root, TreapNode<K,V> parent, K key, V value)
    {
        // If root is NULL, create a new node and return it
        if (root == null){
            return new TreapNode(key, value, parent);
        }
        int greaterThanRoot = comparator.compare(key, root.key);

        // If key is smaller than root
        if (greaterThanRoot < 0)
        {
            // Insert in left subtree
            root.left = insertUsingComparator(root.left, root, key, value);

            // Fix Max Heap property if it is violated
            if (root.left.priority > root.priority) {
                root = rightRotate(root);
            }
        }
        else  // If key is greater / equal to the root
        {
            // Insert in right subtree
            root.right = insertUsingComparator(root.right, root, key, value);

            // Fix Max Heap property if it is violated
            if (root.right.priority > root.priority) {
                root = leftRotate(root);
            }
        }
        return root;
    }

    /**
     * Returns the number of nodes in the Treap
     *
     * @return
     */
    @Override
    public int size() {
        return size;
    }

    // IMPLEMENTED METHODS (SortedMap Interface)

    /**
     * Returns the Treap's comparator or null if natural ordering
     *
     * @return
     */
    @Override
    public Comparator<? super K> comparator() {
        return comparator;
    }

    /**
     * Creates an EntrySet instance, which backs the Treap
     * @return
     */
    @Override
    public Set<SortedMap.Entry<K,V>> entrySet() {
        return new EntrySet(this);
    }

    /**
     * Returns the first key inserted into the Treap
     * @return
     */
    @Override
    public K firstKey() {

        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return getFirstEntry().key;
    }

    /**
     * Returns the last key inserted into the Treap
     *
     * @return
     */
    @Override
    public K lastKey() {

        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return getLastEntry().key;
    }

    /**
     * Creates a subset of the Treap with a specified range of keys
     * @param fromKey
     * @param toKey
     * @return
     */
    @Override
    public SortedMap<K,V> subMap(K fromKey, K toKey) {
        return new SubMap(this, fromKey, toKey);
    }

    // HELPER METHODS

    /**
     * Utility function to left rotate the subtree with root x
     */
    public TreapNode<K,V> leftRotate(TreapNode<K,V> p)
    {
        TreapNode<K,V> r = null;
        if (p != null) {
            r = p.right;
            p.right = r.left;
            if (r.left != null) {
                r.left.parent = p;
            }
            r.parent = p.parent;
            if(p.parent == null) {
                root = r;
            }
            else if (p.parent.left == p) {
                p.parent.left = r;
            }
            else {
                p.parent.right = r;
            }
            r.left = p;
            p.parent = r;
        }
        // Return new root
        return r;
    }

    /**
     * Utility function to right rotate the subtree with root y
     */
    public TreapNode<K,V> rightRotate(TreapNode<K,V> p)
    {
        TreapNode<K,V> l = null;
        if (p != null) {
            l = p.left;
            p.left = l.right;
            if (l.right != null) {
                l.right.parent = p;
            }
            l.parent = p.parent;
            if(p.parent == null) {
                root = l;
            }
            else if (p.parent.right == p) {
                p.parent.right = l;
            }
            else {
                p.parent.left = l;
            }
            l.right = p;
            p.parent = l;
        }
        return l;
    }

    public TreapNode<K,V> successor(TreapNode<K,V> node) {

        // code here is from the treemap.java
        if (node == null) {
            return null;
        }
        else if (node.right != null) {
            TreapNode<K,V> p = node.right;
            while (p.left != null) {
                p = p.left;
            }
            return p;
        }
        else {
            TreapNode<K,V> p = node.parent;
            TreapNode<K,V> ch = node;
            while (p != null && ch == p.right) {
                ch = p;
                p = p.parent;
            }
            return p;
        }
    }

    public TreapNode<K,V> getFirstEntry() {

        TreapNode<K,V> node = root;
        if (node == null) {
            return null;
        }
        else {
            while (node.left != null) {
                node = node.left;
            }
            return node;
        }
    }

    public TreapNode<K,V> getLastEntry() {

        TreapNode<K,V> node = root;
        if (node == null) {
            return null;
        }
        else {
            while (node.right != null) {
                node = node.right;
            }
            return node;
        }
    }

    public boolean setValue(K key, V value) {

        for (TreapNode<K,V> node = getFirstEntry(); node != null; node = successor(node)) {
            if (key.equals(node.key)) {
                node.setValue(value);
                return true;
            }
        }
        return false;
    }

    // DO A FUCKING THING - GET THE NODE REFERENCE
    public TreapNode<K,V> getEntry(K key) {

        TreapNode<K,V> node = root;

        if (comparator == null) {
            while (node != null) {
                Comparable<? super K> k = (Comparable<? super K>) key;
                int result = k.compareTo(node.key);
                if (result < 0) {
                    node = node.left;
                } else if (result > 0) {
                    node = node.right;
                } else return node;
            }
        }
        // looking for a node using the comparator
        else {
            while (node != null) {
                int result = comparator.compare(key, node.key);
                if (result < 0) {
                    node = node.left;
                } else if (result > 0) {
                    node = node.right;
                } else return node;
            }
        }
        return node;
    }

    // UNSUPPORTED METHODS (Map/SortedMap Interface)

    @Override
    public SortedMap<K, V> headMap(K toKey) {
        throw new UnsupportedOperationException();
    }

    @Override
    public SortedMap<K, V> tailMap(K fromKey) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Set<K> keySet() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Collection<V> values() {
        throw new UnsupportedOperationException();
    }

    @Override
    public V remove(Object key) {
        throw new UnsupportedOperationException();
    }

    // INNER BACKING STRUCTURE CLASSES (EntrySet and SubMap)

    /**
     * EntrySet class is the backing structure for the Treap
     * @param <K>
     * @param <V>
     */
    protected class EntrySet<K,V> extends AbstractSet<Map.Entry<K,V>>
            implements Set<Map.Entry<K,V>> {

        private Treap treap;
        private int size;
        K startKey = null;
        K endKey = null;

        public EntrySet(Treap treap) {
            this.treap = treap;
            this.size = treap.size;
        }

        public EntrySet(Treap treap, int size, K startKey, K endKey) {
            this.treap = treap;
            this.size = size;
            this.startKey = startKey;
            this.endKey = endKey;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {

            if (startKey != null && endKey != null) {
                return new Treap.SubMapIterator(startKey, endKey);
            }
            return new Treap.EntryIterator();
        }

        public boolean add(TreapNode<K,V> entry) {
            treap.put(entry.key, entry.value);
            return true;
        }

        @Override
        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry)) {
                return false;
            }
            Map.Entry<K,V> node = (Map.Entry<K,V>) o;
            V value = node.getValue();              // value of treap node parameter
            V value2 = (V) get(node.getKey());      // value of node found
            return (value2 != null && value.equals(value2));
        }

        @Override
        public boolean isEmpty() {
            return treap.isEmpty();
        }

        @Override
        public int size() {
            if (startKey != null && endKey != null) {
                return this.size;
            }
            return treap.size;
        }
    }

    /**
     * SubMap is the backing structure for a subset of the Treap
     * @param <K>
     * @param <V>
     */
    protected class SubMap<K,V> extends AbstractMap<K,V> implements SortedMap<K,V> {

        Treap treap;                                // current treap
        K fromKey;                                  // start key
        K toKey;                                    // end key
        int size;

        SubMap(Treap treap, K fromKey, K toKey) {

            this.treap = treap;
            Comparable<? super K> fromkey = (Comparable<? super K>) fromKey;
            Comparable<? super K> tokey = (Comparable<? super K>) toKey;

            // check validity of range points
            if (fromkey == null || tokey == null) {
                throw new ClassCastException();
            }
            else if (fromKey == null || toKey == null) {
                throw new NullPointerException();
            }
            if (!validateRange(fromKey, toKey)) {
                throw new IllegalArgumentException("fromKey > toKey");
            }
            this.fromKey = fromKey;
            this.toKey = toKey;
            this.size = size();
        }

        // Map Functions *****************************************************

        @Override
        public int size() {
            int submap_size = 0;
            Set<Entry<K,V>> set = entrySet();
            Iterator<SortedMap.Entry<K,V>> itr = set.iterator();
            while (itr.hasNext()) {
                itr.next();
                submap_size++;
            }
            return submap_size;
        }

        @Override
        public boolean isEmpty() {
            Set<Entry<K,V>> set = entrySet();
            Iterator<SortedMap.Entry<K,V>> itr = set.iterator();
            return !(itr.hasNext());
        }

        @Override
        public boolean containsKey(Object o) {
            ArrayList<K> list = new ArrayList();
            Set<Entry<K,V>> set = entrySet();
            Iterator<SortedMap.Entry<K,V>> itr = set.iterator();
            while (itr.hasNext()) {
                list.add(itr.next().getKey());
            }
            return list.contains(o);
        }

        @Override
        public boolean containsValue(Object o) {
            ArrayList<V> list = new ArrayList();
            Set<Entry<K,V>> set = entrySet();
            Iterator<SortedMap.Entry<K,V>> itr = set.iterator();
            while (itr.hasNext()) {
                list.add(itr.next().getValue());
            }
            return list.contains(o);
        }

        @Override
        public V put(K key, V value) {
            Comparable<? super K> fromkey = (Comparable<? super K>) fromKey;
            Comparable<? super K> tokey = (Comparable<? super K>) toKey;
            if (fromkey == null || tokey == null) {
                throw new ClassCastException();
            }
            if (key == null || value == null) {
                throw new NullPointerException();
            }
            if (!validateKey(key, fromKey, toKey)) {
                throw new IllegalArgumentException();
            }
            return (V) treap.put(key, value);
        }

        // SortedMap Functions **************************************************

        @Override
        public Comparator<? super K> comparator() {
            return treap.comparator;
        }

        @Override
        public Set<Entry<K, V>> entrySet() {
            return new EntrySet(treap, size, fromKey, toKey);
        }

        @Override
        public SortedMap<K,V> subMap(K from, K to) {
            if (!validateSubmap(from, fromKey, toKey) ||
                    !validateSubmap(to, fromKey, toKey)) {
                throw new IllegalArgumentException();
            }
            return new SubMap(treap, from, to);
        }

        @Override
        public K firstKey() {
            if (this.isEmpty()) {
                throw new NoSuchElementException();
            }
            return getFirstSubmapEntry().key;
        }

        @Override
        public K lastKey() {
            if (this.isEmpty()) {
                throw new NoSuchElementException();
            }
            return getLastSubmapEntry().key;
        }

        // Helper Functions ****************************************************

        public boolean validateRange(K from, K to) {
            Comparator<K> comp = treap.comparator;
            if (comp == null) {
                Comparable<? super K> fromkey = (Comparable<? super K>) from;
                return (fromkey.compareTo(to) <= 0);
            }
            else {
                return (comp.compare(from, to) <= 0);
            }
        }

        public boolean validateSubmap(K key, K from, K to) {
            if (comparator == null) {
                Comparable<? super K> k = (Comparable<? super K>) key;
                return (k.compareTo(from) >= 0 && k.compareTo(to) <= 0);
            }
            else {
                return (comparator().compare(key, from) >= 0
                        && comparator().compare(key, to) <= 0);
            }
        }

        public boolean validateKey(K key, K from, K to) {
            if (comparator == null) {
                Comparable<? super K> k = (Comparable<? super K>) key;
                return (k.compareTo(from) >= 0 && k.compareTo(to) < 0);
            }
            else {
                return (comparator().compare(key, from) >= 0
                        && comparator().compare(key, to) < 0);
            }
        }

        public TreapNode<K,V> getFirstSubmapEntry() {
            // iterate from treap root -> first entry within range
            for (TreapNode<K, V> node = treap.getFirstEntry(); node != null; node = treap.successor(node)) {
                if (validateKey(node.key, fromKey, toKey)) {
                    return node;
                }
            }
            return null;
        }

        public TreapNode<K,V> getLastSubmapEntry() {
            // iterate from first submap entry -> first entry out of range
            for (TreapNode<K, V> node = getFirstSubmapEntry(); node != null; node = treap.successor(node)) {
                TreapNode<K, V> succ = treap.successor(node);
                if (succ != null && !validateKey(succ.key, fromKey, toKey)) {
                    return node;
                }
            }
            return null;
        }

        // Unsupported Operations ********************************************

        @Override
        public SortedMap<K, V> headMap(K toKey) {
            throw new UnsupportedOperationException();
        }

        @Override
        public SortedMap<K, V> tailMap(K fromKey) {
            throw new UnsupportedOperationException();
        }
    }

    // INNER ITERATOR CLASSES (TreapIterator, EntrySetIterator, SubmapIterator)

    /**
     * TreapIterator is the base class for Treap iterator
     */
    abstract protected class TreapIterator implements Iterator<Map.Entry<K,V>> {

        TreapNode<K,V> next;
        TreapNode<K,V> lastReturned;
        int expModCount;
        K startKey = null;
        K endKey = null;

        public TreapIterator() {
            expModCount = modCount;             // current number of mods
            lastReturned = null;                // node returned last
            next = getFirstEntry();             // start node
        }

        // constructor for iterating over a submap
        TreapIterator(K startKey, K endKey) {
            this.startKey = startKey;
            this.endKey = endKey;

            expModCount = modCount;             // current number of mods
            lastReturned = null;                // node returned last
            next = getFirstSubmapEntry();       // start node
        }

        public final boolean hasNext() {
            if (next != null &&  endKey != null) {
                if (!validateKey(next.key)) {
                    return false;
                }
            }
            return next != null;
        }

        public final TreapNode<K,V> nextEntry() {
            TreapNode<K,V> node = next;
            if (node == null) {
                throw new NoSuchElementException();
            }
            if (modCount != expModCount) {
                throw new ConcurrentModificationException();
            }
            next = successor(node);
            lastReturned = node;
            return node;
        }

        public TreapNode<K,V> getFirstSubmapEntry() {
            // iterate from treap root -> first entry within range
            for (TreapNode<K, V> node = getFirstEntry(); node != null; node = successor(node)) {
                if (validateKey(node.key)) {
                    return node;
                }
            }
            return null;
        }

        public boolean validateKey(K key) {
            if (comparator == null) {
                Comparable<? super K> k = (Comparable<? super K>) key;
                return (k.compareTo(startKey) >= 0 && k.compareTo(endKey) < 0);
            }
            else {
                return (comparator().compare(key, startKey) >= 0
                        && comparator().compare(key, endKey) < 0);
            }
        }
    }

    /**
     * EntryIterator class enables easy iteration through Treap items
     * Extends TreapIterator<Map.Entry<K,V>>
     */
    final class EntryIterator extends TreapIterator {

        EntryIterator() {
            super();
        }

        public Map.Entry<K,V> next() {
            return nextEntry();
        }
    }

    /**
     * SubmapIterator class enables easy iteration through a Treap submap
     * Extends TreapIterator<SortedMap.Entry<K,V>>
     */
    final class SubMapIterator extends TreapIterator {

        SubMapIterator(K startKey, K endKey) {
            super(startKey, endKey);
        }

        public Map.Entry<K,V> next() {
            return nextEntry();
        }
    }
}