package cmsc420.meeshquest.part2;
import java.util.Comparator;

/**
 * Comparator class for sorting PriorityQueue based on point
 */
public class PQRoadComparator implements Comparator<RoadDistance> {

    @Override
    /**
     * Compare method for comparing RoadDistance objects
     * @param v1 = distance 1
     * @param v2 = distance 2
     * @return
     */
    public int compare(RoadDistance v1, RoadDistance v2) {

        if (v1.getDistance() > v2.getDistance()) {
            return 1;
        } else if (v1.getDistance() < v2.getDistance()) {
            return -1;
        } else return 0;
    }
}
